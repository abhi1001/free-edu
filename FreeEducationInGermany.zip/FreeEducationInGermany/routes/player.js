const fs = require('fs');

module.exports = {
    addPlayerPage: (req, res) => {
        res.render('add-player.ejs', {
            title: "Free Education In Germany"
            ,message: ''
        });
    },
    addPlayer: (req, res) => {

        let message = '';
        let name = req.body.name;
        let email = req.body.email;
        let dob = req.body.dob;
        let tel = req.body.tel;
        let whatsapp = req.body.whatsapp;
        let address = req.body.address;

        let emailQuery = "SELECT * FROM `member` WHERE email = '" + email + "'";

        db.query(emailQuery, (err, result) => {
            if (err) {
                return res.status(500).send(err);
            }
            if (result.length > 0) {
                message = 'Email already exists';
                res.render('add-player.ejs', {
                    message,
                    title: "Free Education In Germany"
                });
            } else {
                        if (err) {
                            return res.status(500).send(err);
                        }
                        // send the player's details to the database
                        let query = "INSERT INTO `member` (name, email, dob, tel, whatsapp, address) VALUES ('" +
                            name + "', '" + email + "', '" + dob + "', '" + tel + "', '" + whatsapp + "', '" + address + "')";
                        db.query(query, (err, result) => {
                            if (err) {
                                return res.status(500).send(err);
                            }
                            res.redirect('/');
                        });
            }
        });
    },
    Apply: (req, res) => {
        res.render('apply.ejs', {
            title: "Free Education In Germany"
            ,message: ''
        });
    },
    Payment: (req, res) => {
        res.render('payment.ejs', {
            title: "Free Education In Germany"
            ,message: ''
        });
    },
    Terms: (req, res) => {
        res.render('terms.ejs', {
            title: "Free Education In Germany"
            ,message: ''
        });
    },
};
